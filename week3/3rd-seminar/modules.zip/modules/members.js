const membersDB = [
{
idx: 0,
name: "최영훈",
part: "서버",
age: 26,
},
{
idx: 1,
name: "이수진",
part: "서버",
age: 23,
},
{
idx: 2,
name: "오승재",
part: "서버",
age: 23,
},
];
module.exports = membersDB;